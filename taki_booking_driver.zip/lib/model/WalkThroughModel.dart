class WalkThroughModel {
  String? text;
  String? name;
  String? img;

  WalkThroughModel({this.text, this.name, this.img});
}
