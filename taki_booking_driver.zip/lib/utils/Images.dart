const DriverIcon = 'images/ic_car.png';
const SourceIcon = 'images/ic_source.png';
const DestinationIcon = 'images/destination_map_marker.png';
const walletGIF = 'images/wallet.gif';
const paymentSuccessful = 'images/Successful.json';

const ic_google = 'images/ic_google.png';
